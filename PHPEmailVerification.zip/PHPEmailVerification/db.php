<?php
$con=mysqli_connect("localhost","root","","vishal");
?>